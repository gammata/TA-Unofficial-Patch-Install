# INSTALLATION

Use the drop in zip and extract to your Escalation Directory. Replace all.

OR

Download 'edraw.dll' and rename it as 'taesc.dll' in your ESCALATION directory. (Remove/Replace the old 'edraw.dll' and 'taesc.dll', they are no longer needed).
Download 'ChatMacro.ini" and "Settings.ini" into your ESCALATION directory.
